-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2018 at 01:14 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventry`
--

-- --------------------------------------------------------

--
-- Table structure for table `car_details`
--

CREATE TABLE `car_details` (
  `car_id` int(11) NOT NULL,
  `m_id` int(11) DEFAULT NULL,
  `model_name` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `reg_no` varchar(255) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `note` text,
  `img_one` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_details`
--

INSERT INTO `car_details` (`car_id`, `m_id`, `model_name`, `color`, `reg_no`, `year`, `note`, `img_one`, `quantity`, `created_at`) VALUES
(1, 1, 'Alto-800', 'blue', 'DL10ABC', 2007, 'Something for Maruti to think about I suppose - because if I were a buyer, expect a bit more for the extra I have to pay for the RS over the Baleno Alpha petrol.', 'maruti-suzuki-baleno.png', 1, '2018-07-14 09:36:57'),
(2, 3, 'Lexus', 'white', 'ty99RTY', 2018, 'Toyota is the worlds market leader in sales of hybrid electric vehicles and one of the largest companies to encourage the mass-market adoption of hybrid vehicles across the globe. Toyota is also a market leader in hydrogen fuel-cell vehicles. ', 'download.jpg', 1, '2018-07-14 10:43:08'),
(3, 2, 'Maruti Swift', 'white', 'GH99RTY', 2018, 'Maruti Suzuki offers 18 new car models in India. Swift, Baleno and Dzire are among the popular cars from Maruti Suzuki. Maruti Suzuki Alto 800 is the lowest priced model ', 'download (1).jpg', 1, '2018-07-14 10:46:25'),
(4, 4, 'Mark XXI', 'black', 'JK78WER', 2018, 'Dramatic Design. Responsive Performance. Sophisticated Technology. Explore Now. Book Online. Automatic Speed Limiter. Explore Jaguar Approved. Financial Options. ', 'images.jpg', 1, '2018-07-14 11:04:32');

-- --------------------------------------------------------

--
-- Table structure for table `manufacturer`
--

CREATE TABLE `manufacturer` (
  `id` int(11) NOT NULL,
  `manufacturer_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manufacturer`
--

INSERT INTO `manufacturer` (`id`, `manufacturer_name`, `created_at`) VALUES
(1, 'SUZUKI', '2018-06-30 12:43:15'),
(2, 'MARUTI', '2018-06-30 12:43:24'),
(3, 'TOYOTA', '2018-07-14 09:28:06'),
(4, 'Jagur', '2018-07-14 11:02:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car_details`
--
ALTER TABLE `car_details`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `manufacturer`
--
ALTER TABLE `manufacturer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car_details`
--
ALTER TABLE `car_details`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `manufacturer`
--
ALTER TABLE `manufacturer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
