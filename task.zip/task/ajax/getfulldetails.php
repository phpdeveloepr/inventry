<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "inventry";
$dbh = mysqli_connect($host,$username,$password,$dbname);
if(isset($_POST['carid']))
{
	
	$result= "";
	$query = "select * from car_details where car_id = '".$_POST['carid']."'";
	$exc = mysqli_query($dbh,$query)or die("Error: " . mysqli_error($dbh));
	$result .='
	<div class="table-resposive">
	<table class="table table-bordered">';
	while ($row = mysqli_fetch_array($exc))
    {
		echo $result .= '<tr>
					<td style="width:20%;"><label>Manufacturer Name<label></td>
					<td style="width:80%;">'.$row['manu_id'].'</td>
					</tr>
					<tr>
					<td style="width:20%;"><label>Model Name<label></td>
					<td style="width:80%;">'.$row['model_name'].'</td>
					</tr>
					<tr>
					<td style="width:20%;"><label>Color<label></td>
					<td style="width:80%;">'.$row['color'].'</td>
					</tr>
					<tr>
					<td style="width:20%;"><label>Year<label></td>
					<td style="width:80%;">'.$row['year'].'</td>
					</tr>
					<tr>
					<td style="width:20%;"><label>Reg Num<label></td>
					<td style="width:80%;">'.$row['reg_no'].'</td>
					</tr>
					<tr>
					<td style="width:20%;"><label>Desc.<label></td>
					<td style="width:80%;">'.$row['note'].'</td>
					</tr>';
		}
		$result .='</table></div>';
		echo $result;
}
?>