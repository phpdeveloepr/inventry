<?php
include('db.php');
if(isset($_POST["car_id"]))
{
 $connect = mysqli_connect("localhost", "root", "", "inventry");
 $output = '';
 $query = " SELECT a.*,b.* FROM car_details as a
            left join manufacturer b on a.m_id = b.id
            WHERE a.car_id = '".$_POST["car_id"]."'";

 
 $result = mysqli_query($conn, $query);
 $output .= '<div class="table-responsive">
    <table class="table table-striped table-bordered">
     <tr>
      <th>Manufacture Name</th>
      <th>Model Name</th>
      <th>Color</th>
      <th>Reg No.</th>
      <th>Year</th>
      <th>Note</th>
      <th>Quantity</th>
      <th>Image</th>
     </tr>';
    
     while($row = mysqli_fetch_array($result))
     {
      $img = $row["img_one"];
      
 $output .= '<tr>
       <td>'.$row["manufacturer_name"].'</td>
       <td>'.$row["model_name"].'</td>
       <td>'.$row["color"].'</td>
       <td>'.$row["reg_no"].'</td>
       <td>'.$row["year"].'</td>
       <td>'.$row["note"].'</td>
       <td>'.$row["quantity"].'</td>
       <td><img style="width:100px;" src="upload/'.$img.' " /></td>';
    }
    $output .='</table></div>';
 echo $output;
}

?>
